package Inheritence;

public interface Expirable {

    void useTicket();
    int getRidesLeft();
}
