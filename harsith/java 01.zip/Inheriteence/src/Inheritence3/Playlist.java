package Inheritence3;

public interface Playlist {

    void addSong(Song song);
    String play(String title);
    int getSongCount();

}
