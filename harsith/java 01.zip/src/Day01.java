public class Day01 {
}
