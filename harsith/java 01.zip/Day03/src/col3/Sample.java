package col3;

public class Sample {
    public String name;
    public String date;
    public boolean tainted;

    public Sample(String name, String date, boolean tainted) {
        this.name = name;
        this.date = date;
        this.tainted = tainted;
    }
}
