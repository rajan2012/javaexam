import java.util.Arrays;

public class ang {

    public static boolean isAnagram(String s1, String s2){

        s1 = s1.toLowerCase();
        s2 = s2.toLowerCase();

        char[] s1new = s1.toCharArray();
        char[] s2new = s2.toCharArray();

        Arrays.sort(s1new);
        Arrays.sort(s2new);

        if(Arrays.equals(s1new,s2new)){
            return true;
        }

        return false;
    }

    public static void main(String[] args){

        String s1 = "Listen";
        String s2 = "SIlent";

        if(isAnagram( s1,  s2)){

            System.out.println(s1 + " and " + s2 + " are anagrams.");
        }
        else {
            System.out.println(s1 + " and " + s2 + " are not anagrams.");
        }

    }
}
