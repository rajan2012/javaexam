package Inheritence02;

public interface Expirable {

    void useTicket();
    int getRidesLeft();

}
