/**
 * @author Peter Birke
 *         birke@uni-trier.de
 *
 * 12.02.2013
 */
public class ExamMath {

    // TODO Implementieren
}
