import java.util.*;
public class Evaluation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Comparison: ");
        
        String test = (sc.nextLine());
        try {
            String result =  Checker.checkComparison(test);
            System.out.println( result );
        }
        catch (RuntimeException e){
            System.out.println(e.getMessage());
        }
    }
}
