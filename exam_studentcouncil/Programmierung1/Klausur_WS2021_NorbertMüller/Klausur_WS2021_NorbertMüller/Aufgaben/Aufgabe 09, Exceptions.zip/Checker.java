import java.util.StringTokenizer;

public class Checker {

    public static void checkComparison(String calculation){
    
    
    

    }

}
