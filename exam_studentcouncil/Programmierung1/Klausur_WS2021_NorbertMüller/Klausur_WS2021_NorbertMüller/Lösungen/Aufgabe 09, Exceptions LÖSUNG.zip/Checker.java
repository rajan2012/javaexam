import java.util.StringTokenizer;

public class Checker {

    public static String checkComparison(String calculation){
        String regex = "[-+]{0,1}[0-9]*[ ]{1}[<>]{1}[ ]{1}[-+]{0,1}[0-9]*";
        if(!calculation.matches(regex)){
            throw new RuntimeException("syntax error");
        }
        StringTokenizer st = new StringTokenizer(calculation, " ");
        int Int1 = Integer.parseInt(st.nextToken());
        String operator = st.nextToken();
        int Int2 = Integer.parseInt(st.nextToken());

        if(operator.equals(">")){
            boolean b = Int1 > Int2;
            if(b){
                return "valid";
            } else{return Int1 + " is not greater than " + Int2;}
        }
        else{
                boolean b = Int1 < Int2;
                if(b){
                    return "valid";
                } else{return Int1 + " is not smaller than " + Int2;
        }





    }

}}
