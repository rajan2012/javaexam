/**
 * @author Peter Birke
 *         birke@uni-trier.de
 *
 * 12.02.2013
 */
public class Project {

  private String title;

  public Project(String title) {
    this.title = title;
  }

  public String getTitle() {
    return title;
  }

  public String toString() {
    return "Project \"" + title + "\"";
  }

  // TODO : Fehlende Methoden ergaenzen
}
