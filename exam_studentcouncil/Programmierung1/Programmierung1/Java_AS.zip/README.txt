Hi!
Es ist schön, dass Du ein paar Java-Grundlagen wiederholen und/oder auffrischen möchtest. Es gibt folgende wichtige Anhaltspunkte:

Die Datei "Aufgabensammlung.java" enthält alle Aufgaben(-teile), die als wichtig angesehen und demnach ausgewählt wurden.
Alle weitere Dateien sollen erst bei der Bearbeitung der einzelnen Aufgaben in Betracht gezogen werden. Ein kurzer Einblick ist aber natürlich erlaubt.

Rat:
1)
Ersetze den src-Ordner in einem Projekt einfach durch den hier zur Verfügung gestellten Ordner und es sollte keine "Start-Schwierigkeiten" geben.
In anderen Worten: Copy-and-Paste, ggf. Ersetzen
2)
Öffne die Aufgabensammlung und hole alle weiteren Dateien stückweise und je Aufgabe dazu. Damit kann an der ein oder anderen Stelle Verwirrung vermieden werden.
Die Dateien sind in gewisser Hinsicht selbsterklärend und füllen dabei nicht allzu viele Codezeilen aus.

Hinweis:
Je nach Aufgabenstellung steigen die Schwierigkeit und der Anspruch ein wenig an - das ist aber auch markiert.

Bei Fragen:
Einfach fragen! Es gibt bestimmt andere Personen, die das gleiche Problem haben!
Zudem werde ich als Ansprechpartner verbleiben und versuchen, möglichst jede Frage zu sichten und beantworten.

Viel Spaß!